﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChkADO.Net
{
    internal class Equipment
    {
        public int EquipmentID { get; set; }
        public string EquipmentName { get; set; }
        public int Qty { get; set; }
        public string Location { get; set; }
        public int SpareID { get; set; }
        public string SpareName { get; set; }
        public string Manufacturer { get; set; }
        public int Quantity { get; set; }
        public int ReorderLimit { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public void AddEquipments(Equipment equObj)
        {
            try
            {

                SqlConnection con = new SqlConnection("Data Source=DESKTOP-C8QCRB6;Initial Catalog=productmanagementsystem;Integrated Security=True;");

                con.Open();
                SqlCommand command = new SqlCommand("AddEquipment", con);
                command.CommandType = CommandType.StoredProcedure;
                
                command.Parameters.AddWithValue("@EquipmentName", equObj.EquipmentName);
                command.Parameters.AddWithValue("@Qty", equObj.Qty);
                command.Parameters.AddWithValue("@Location", equObj.Location);
                int results = command.ExecuteNonQuery();
                Console.WriteLine(results + " equipment added successfully.");
                
                //con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while adding equipment: " + ex.Message);
            }

        }
        public void AddSpares(Equipment equObj)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-C8QCRB6;Initial Catalog=productmanagementsystem;Integrated Security=True;");

            con.Open();
            SqlCommand command = new SqlCommand("AddSpare", con);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@SpareName", equObj.SpareName);
            command.Parameters.AddWithValue("@Manufacturer", equObj.Manufacturer);
            command.Parameters.AddWithValue("@Qty", equObj.Quantity);
            command.Parameters.AddWithValue("@ReorderLimit",equObj.ReorderLimit);
            int results = command.ExecuteNonQuery();
            Console.WriteLine(results + " spare added successfully.");
                
            //con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while adding equipment: " + ex.Message);
            }

        }
        public void ChangeSpareForEquipment(Equipment equObj)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-C8QCRB6;Initial Catalog=productmanagementsystem;Integrated Security=True;");

            con.Open();
            SqlCommand command = new SqlCommand("ChangeSpareForEquipment", con);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@EquipmentID",equObj.EquipmentID);
            command.Parameters.AddWithValue("@SpareID",equObj.SpareID);
            int results = command.ExecuteNonQuery();
            Console.WriteLine( " equipment spare changed successfully.");
                
            //con.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while adding equipment: " + ex.Message);
            }
         


        }
        public void Login()
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-C8QCRB6;Initial Catalog=productmanagementsystem;Integrated Security=True;");

                con.Open();
                SqlCommand command = new SqlCommand("LoginDetails", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Username", Username);
                command.Parameters.AddWithValue("@Password", Password);
                object result = command.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                {
                    int count = Convert.ToInt32(result);
                    
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while adding equipment: " + ex.Message);
            }


        }
        public void ResetPassword()
        {
            try
            {
                Console.Write("Enter Username: ");
                string username = Console.ReadLine();

                Console.Write("Enter New Password: ");
                string newPassword = Console.ReadLine();
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-C8QCRB6;Initial Catalog=productmanagementsystem;Integrated Security=True;");

                con.Open();
                SqlCommand command = new SqlCommand("ResetPassword", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@NewPassword", newPassword);

                SqlParameter rowsAffectedParameter = new SqlParameter();
                rowsAffectedParameter.ParameterName = "@RowsAffected";
                rowsAffectedParameter.SqlDbType = SqlDbType.Int;
                rowsAffectedParameter.Direction = ParameterDirection.Output;
                command.Parameters.Add(rowsAffectedParameter);

                command.ExecuteNonQuery();

                int rowsAffected = Convert.ToInt32(command.Parameters["@RowsAffected"].Value);
                Console.WriteLine(rowsAffected + " password reset successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while resetting password: " + ex.Message);
            }
        }

    }
    class EquipmentManagement
    {
        public static void Main()
        {
            Equipment equObj = new Equipment();
            Console.WriteLine("Enter Username:");
            string username = Console.ReadLine();
            Console.WriteLine("Enter Password:");
            string password = Console.ReadLine();
            Equipment user = new Equipment()
            {
                Username = username,
                Password = password,
            };
            if (user == null)
            {
                Console.WriteLine("login success");
            }
            else
            {
                Console.WriteLine("login success");
            }


            do
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Add Equipments");
                Console.WriteLine("2. Add Spares");
                Console.WriteLine("3. Change spare for the equipment");
                Console.WriteLine("4. Reset Password");
                Console.WriteLine("5.Exit");
                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("How many equipment details you want to store");
                        choice = Convert.ToInt32(Console.ReadLine());
                        for (int i = 0; i < choice; i++)
                        {
                            Console.WriteLine("Enter the Equipment name");
                            equObj.EquipmentName = Console.ReadLine();
                            Console.WriteLine("Enter the Quantity");
                            equObj.Qty = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter the location");
                            equObj.Location = Console.ReadLine();
                            equObj.AddEquipments(equObj);
                        }
                        break;
                    case 2:
                        Console.WriteLine("How many spare details you want to store");
                        choice = Convert.ToInt32(Console.ReadLine());
                        for (int i = 0; i < choice; i++)
                        {
                            Console.WriteLine("Enter the Spare name");
                            equObj.SpareName = Console.ReadLine();
                            Console.WriteLine("Enter the manufacturer");
                            equObj.Manufacturer = Console.ReadLine();
                            Console.WriteLine("Enter the Quantity");
                            equObj.Quantity = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter the reorder limit");
                            equObj.ReorderLimit = Convert.ToInt32(Console.ReadLine());
                            equObj.AddSpares(equObj);
                        }
                        break;
                    case 3:
                        Console.WriteLine("Enter the equipmentid");
                        equObj.EquipmentID = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter the spareid");
                        equObj.SpareID = Convert.ToInt32(Console.ReadLine());
                        equObj.ChangeSpareForEquipment(equObj);
                        break;
                    case 4:
                        equObj.ResetPassword();
                        break;
                    case 5:
                        return;




                }
            } while (true);
        }
    }
}
